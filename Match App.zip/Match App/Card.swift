//
//  Card.swift
//  Match App
//
//  Created by macOS on 27/04/20.
//  Copyright © 2020 macOS. All rights reserved.
//

import Foundation

class Card{
    
    var imageName = ""
    var isFlipped = false
    var isMatched = false
    
}
